<?php
return [
    'id' => 'reddit_profiles',
    'name' => 'Reddit profiles',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fab fa-reddit',
    'color' => '#4267b2'
];