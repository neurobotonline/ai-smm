<?php
$lang["Please select a profile to add"] = "Please select a profile to add";
$lang["No profile to add"] = "No profile to add";
$lang["Success"] = "Success";
$lang["Reddit profiles"] = "Reddit profiles";
$lang["Reddit profile"] = "Reddit profile";
$lang["Add Reddit profile"] = "Add Reddit profile";
$lang["Reddit"] = "Reddit";
$lang["Reddit API Configuration"] = "Reddit API Configuration";
$lang["Add profile"] = "Add profile";
$lang["Choose the profile you'd like to manage"] = "Choose the profile you'd like to manage";
$lang["Search"] = "Search";
$lang["If you don't see your profiles above, you might try to reconnec, re-accept all permissions, and ensure that you're logged in to the correct profile."] = "If you don't see your profiles above, you might try to reconnec, re-accept all permissions, and ensure that you're logged in to the correct profile.";
$lang["Re-connect with Reddit"] = "Re-connect with Reddit";
$lang["Redirect URI:"] = "Redirect URI:";
$lang["Click this link to create Reddit app:"] = "Click this link to create Reddit app:";
$lang["Reddit client id"] = "Reddit client id";
$lang["Reddit client secret"] = "Reddit client secret";