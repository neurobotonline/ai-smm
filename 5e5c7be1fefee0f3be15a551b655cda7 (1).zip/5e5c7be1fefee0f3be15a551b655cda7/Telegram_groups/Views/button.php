<a href="<?php _e( base_url( $config['id']."/oauth" ) )?>" class="btn btn-outline btn-outline-dashed me-2 mb-2 text-start list-btn-add-account">
    <i class="<?php _e( $config['icon'] )?>" style="color: <?php _e( $config['color'] )?>;" ></i> 
    <?php _ec("Add Telegram group")?>
</a>